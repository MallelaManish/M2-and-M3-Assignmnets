package com.cg.anurag.spmvc;
import javax.servlet.ServletContext;
import javax.servlet.ServletRegistration;
import org.springframework.web.WebApplicationInitializer;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.XmlWebApplicationContext;
import org.springframework.web.servlet.DispatcherServlet;
import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;
import org.springframework.web.servlet.support.AbstractDispatcherServletInitializer;
public class AppIntializer {

 //extends AbstractAnnotationConfigDispatcherServletInitializer
{
	/*public Class<?>[] getRootConfigClasses()
	{
		return null;
	}
	public Class<?>[] getServletConfigClasses()
	{
		return new Class[] {SpmvcAppConfig.class};
	}
	public String[] getServletMappings()
    {
   	 return new String[] {"/"};
    }*/
}

}
